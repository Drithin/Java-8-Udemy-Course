package com.Java8UdemyCourse.ChallengeExercise;

public class Window {
	
	private String windowShape;
	private int windowLength;
	/**
	 * @param windowShape
	 * @param windowLength
	 */
	public Window(String windowShape, int windowLength) {
		
		this.windowShape = windowShape;
		this.windowLength = windowLength;
	}
	public String getWindowShape() {
		return windowShape;
	}
	public int getWindowLength() {
		return windowLength;
	}
	
	

}
