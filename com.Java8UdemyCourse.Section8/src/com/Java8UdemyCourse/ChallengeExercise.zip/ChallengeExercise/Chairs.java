package com.Java8UdemyCourse.ChallengeExercise;

public class Chairs {
	
	private int legs;
	private String material;
	/**
	 * @param legs
	 * @param material
	 */
	public Chairs(int legs, String material) {
		
		this.legs = legs;
		this.material = material;
	}
	public int getLegs() {
		return legs;
	}
	public String getMaterial() {
		return material;
	}
	
	

}
